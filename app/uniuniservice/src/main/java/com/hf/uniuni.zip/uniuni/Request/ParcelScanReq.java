package com.hf.uniuni.Request;

public class ParcelScanReq {
    private String tracking_no;
    private long scan_batch_id;

    public ParcelScanReq() {}

    public String getTracking_no() {
        return tracking_no;
    }
    public void setTracking_no(String tracking_no) {
        this.tracking_no = tracking_no;
    }

    public long getScan_batch_id() {
        return scan_batch_id;
    }
    public void setScan_batch_id(long scan_batch_id) {
        this.scan_batch_id = scan_batch_id;
    }
}
