package com.hf.uniuni.Response;

import com.hf.courierservice.IResponseCallBack;
import com.hf.courierservice.Result;
import com.hf.courierservice.bean.DeliveringListData;
import com.hf.courierservice.apihelper.TaskBase;

import java.util.List;
import java.util.ListIterator;

public class GetDeliveringListRsp implements TaskBase<List<DeliveringListData>> {
    private String biz_code;
    private String biz_message;
    private List<DeliveringListData> biz_data;
    public void setBiz_code(String biz_code) {
        this.biz_code = biz_code;
    }
    public String getBiz_code() {
        return biz_code;
    }

    public void setBiz_message(String biz_message) {
        this.biz_message = biz_message;
    }
    public String getBiz_message() {
        return biz_message;
    }

    public void setBiz_data(List<DeliveringListData> biz_data) {
        this.biz_data = biz_data;
    }
    public List<DeliveringListData> getBiz_data() {
        return biz_data;
    }


    @Override
    public void doIt(IResponseCallBack<List<DeliveringListData>> cb) {
        List<DeliveringListData> lst = this.getBiz_data();
        ListIterator<DeliveringListData> listIterator = lst.listIterator();

        cb.onComplete(new Result.Success<List<DeliveringListData>>(lst));
    }
}