package com.hf.uniuni.Request;

/**
 * 查询司机扫描报告的请求参数
 */
public class ScanBatchReportReq {
    private int warehouse;
    private int driver_id;
    private String start_date; // 格式 "YYYY-MM-DD"

    public ScanBatchReportReq() {}

    public int getWarehouse() {
        return warehouse;
    }
    public void setWarehouse(int warehouse) {
        this.warehouse = warehouse;
    }

    public int getDriver_id() {
        return driver_id;
    }
    public void setDriver_id(int driver_id) {
        this.driver_id = driver_id;
    }

    public String getStart_date() {
        return start_date;
    }
    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }
}
