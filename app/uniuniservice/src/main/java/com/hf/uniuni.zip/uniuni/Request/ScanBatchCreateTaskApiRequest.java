package com.hf.uniuni.Request;

import com.android.volley.Request;
import com.hf.courierservice.apihelper.ApiRequestBase;
import com.hf.uniuni.CourierService;
import com.hf.uniuni.Response.ScanBatchCreateRsp;

import java.util.HashMap;

/**
 * 创建扫描批次 API 请求
 */
public class ScanBatchCreateTaskApiRequest
        extends ApiRequestBase<ScanBatchCreateReq, ScanBatchCreateRsp> {

    private static final String PATH = "delivery/scan/batch";

    public ScanBatchCreateTaskApiRequest(ScanBatchCreateReq req) {
        super(req, ScanBatchCreateRsp.class);
        mUrl = CourierService.DOMAIN_API + PATH;
        setMethod(Request.Method.POST);

        HashMap<String, String> headers = new HashMap<>();
        headers.put("authorization", "Bearer" + " " + CourierService.userToken);
        setHeader(headers);
    }
}
