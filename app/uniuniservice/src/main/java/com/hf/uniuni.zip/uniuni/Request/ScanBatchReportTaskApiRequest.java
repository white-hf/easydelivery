package com.hf.uniuni.Request;

import com.android.volley.Request;
import com.hf.courierservice.apihelper.ApiRequestBase;
import com.hf.uniuni.Response.ScanBatchReportRsp;
import com.hf.uniuni.CourierService;

/**
 * 查询司机扫描报告的 API 请求
 */
public class ScanBatchReportTaskApiRequest
        extends ApiRequestBase<ScanBatchReportReq, ScanBatchReportRsp> {

    private static final String PATH = "delivery/ext/scan/batch/reports";

    public ScanBatchReportTaskApiRequest(ScanBatchReportReq req) {
        super(req, ScanBatchReportRsp.class);
        // 拼接带参数的 URL
        mUrl = CourierService.DOMAIN_API
                + PATH
                + "?warehouse="  + req.getWarehouse()
                + "&driver_id="  + req.getDriver_id()
                + "&start_date=" + req.getStart_date();
        setMethod(Request.Method.GET);
    }
}
