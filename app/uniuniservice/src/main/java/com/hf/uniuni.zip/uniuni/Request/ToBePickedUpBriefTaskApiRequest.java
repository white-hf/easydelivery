package com.hf.uniuni.Request;

import com.android.volley.Request;
import com.hf.courierservice.apihelper.ApiRequestBase;
import com.hf.uniuni.CourierService;
import com.hf.uniuni.Response.ToBePickedUpBriefRsp;

import java.util.HashMap;

/**
 * 查询待分拣扫描包裹概要 API 请求
 */
public class ToBePickedUpBriefTaskApiRequest
        extends ApiRequestBase<CommonReq, ToBePickedUpBriefRsp> {

    private static final String PATH = "delivery/to-be-picked-up/brief/";

    public ToBePickedUpBriefTaskApiRequest(CommonReq req, int driverId) {
        super(req, ToBePickedUpBriefRsp.class);
        mUrl = CourierService.DOMAIN_API + PATH + driverId;
        setMethod(Request.Method.GET);

        HashMap<String, String> headers = new HashMap<>();
        headers.put("authorization", "Bearer" + " " + CourierService.userToken);
        setHeader(headers);
    }
}
