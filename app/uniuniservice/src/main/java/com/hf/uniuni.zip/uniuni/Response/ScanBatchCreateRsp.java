package com.hf.uniuni.Response;

import com.hf.courierservice.IResponseCallBack;
import com.hf.courierservice.Result;
import com.hf.courierservice.apihelper.TaskBase;
import com.hf.courierservice.bean.ScanBatchCreateData;

/**
 * 创建扫描批次响应
 */
public class ScanBatchCreateRsp implements TaskBase<ScanBatchCreateData> {
    private String biz_code;
    private String biz_message;
    private ScanBatchCreateData biz_data;

    public String getBiz_code() {
        return biz_code;
    }
    public void setBiz_code(String biz_code) {
        this.biz_code = biz_code;
    }

    public String getBiz_message() {
        return biz_message;
    }
    public void setBiz_message(String biz_message) {
        this.biz_message = biz_message;
    }

    public ScanBatchCreateData getBiz_data() {
        return biz_data;
    }
    public void setBiz_data(ScanBatchCreateData biz_data) {
        this.biz_data = biz_data;
    }

    @Override
    public void doIt(IResponseCallBack<ScanBatchCreateData> cb) {
        if ("PICKUP.SCAN.STARTED".equalsIgnoreCase(biz_code)) {
            cb.onComplete(new Result.Success<>(biz_data));
        } else {
            cb.onFail(new Exception(biz_message));
        }
    }
}
