package com.hf.uniuni.Response;

import com.hf.courierservice.IResponseCallBack;
import com.hf.courierservice.Result;
import com.hf.courierservice.apihelper.TaskBase;
import com.hf.uniuni.CourierService;

public class AppLoginRsp implements TaskBase<String> {
    private String biz_code;
    private String biz_message;
    private Biz_data biz_data;
    public void setBiz_code(String biz_code) {
        this.biz_code = biz_code;
    }
    public String getBiz_code() {
        return biz_code;
    }

    public void setBiz_message(String biz_message) {
        this.biz_message = biz_message;
    }
    public String getBiz_message() {
        return biz_message;
    }

    public void setBiz_data(Biz_data biz_data) {
        this.biz_data = biz_data;
    }
    public Biz_data getBiz_data() {
        return biz_data;
    }

    @Override
    public void doIt(IResponseCallBack<String> cb) {
        if (this.getBiz_code().equalsIgnoreCase("COMMON.QUERY.SUCCESS")) {
            CourierService.userToken = this.getBiz_data().getAccess_token();

            cb.onComplete(new Result.Success<String>(""));
        } else {
            Exception ex = new Exception(getBiz_message());
            cb.onFail(ex);
        }
    }
}
