package com.hf.uniuni.Request;

/**
 * 生成扫描报告请求参数
 */
public class ScanBatchGenerateReportReq {
    private long scan_batch_id;

    public long getScan_batch_id() {
        return scan_batch_id;
    }
    public void setScan_batch_id(long scan_batch_id) {
        this.scan_batch_id = scan_batch_id;
    }
}
