package com.hf.uniuni.Request;

import static com.hf.uniuni.CourierService.DOMAIN_API;

import com.hf.uniuni.Response.GetDeliveringListRsp;
import com.hf.courierservice.apihelper.*;
import com.hf.uniuni.CourierService;

import java.util.HashMap;

public class GetDeliveryTaskApiRequest extends ApiRequestBase<CommonReq, GetDeliveringListRsp> {

    private static final String URL_DELIVERING_LIST = DOMAIN_API + "delivery/parcels/delivering?driver_id=";
    public static final String URL_UNSCANNED_LIST = DOMAIN_API + "delivery/parcels/tasks?criteria=UNSCANNED&driver_id=";

    public GetDeliveryTaskApiRequest(CommonReq req , String driverId , boolean bDelivering) {
        super(req, GetDeliveringListRsp.class);

        if (!bDelivering)
            mUrl = URL_UNSCANNED_LIST;
        else
            mUrl = URL_DELIVERING_LIST;
        mUrl += driverId;

        HashMap<String,String> headers = new HashMap<>();
        headers.put("authorization", "Bearer" + " " + CourierService.userToken);

        this.setHeader(headers);
    }
}