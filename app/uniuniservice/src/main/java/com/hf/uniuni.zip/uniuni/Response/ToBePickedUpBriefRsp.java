package com.hf.uniuni.Response;

import com.hf.courierservice.IResponseCallBack;
import com.hf.courierservice.Result;
import com.hf.courierservice.apihelper.TaskBase;
import com.hf.courierservice.bean.ToBePickedUpBriefData;

/**
 * 查询待分拣扫描包裹概要响应
 */
public class ToBePickedUpBriefRsp implements TaskBase<ToBePickedUpBriefData> {
    private String biz_code;
    private String biz_message;
    private ToBePickedUpBriefData biz_data;

    public String getBiz_code() {
        return biz_code;
    }
    public void setBiz_code(String biz_code) {
        this.biz_code = biz_code;
    }

    public String getBiz_message() {
        return biz_message;
    }
    public void setBiz_message(String biz_message) {
        this.biz_message = biz_message;
    }

    public ToBePickedUpBriefData getBiz_data() {
        return biz_data;
    }
    public void setBiz_data(ToBePickedUpBriefData biz_data) {
        this.biz_data = biz_data;
    }

    @Override
    public void doIt(IResponseCallBack<ToBePickedUpBriefData> cb) {
        if ("COMMON.QUERY.SUCCESS".equalsIgnoreCase(biz_code)) {
            cb.onComplete(new Result.Success<>(biz_data));
        } else {
            cb.onFail(new Exception(biz_message));
        }
    }
}
