package com.hf.uniuni.Request;

import com.android.volley.Request;
import com.hf.courierservice.apihelper.ApiRequestBase;
import com.hf.uniuni.CourierService;
import com.hf.uniuni.Response.ScanBatchGenerateReportRsp;

import java.util.HashMap;

/**
 * 生成扫描报告 API 请求
 */
public class ScanBatchGenerateReportTaskApiRequest
        extends ApiRequestBase<ScanBatchGenerateReportReq, ScanBatchGenerateReportRsp> {

    private static final String PATH = "delivery/scan/batch/report";

    public ScanBatchGenerateReportTaskApiRequest(ScanBatchGenerateReportReq req) {
        super(req, ScanBatchGenerateReportRsp.class);
        mUrl = CourierService.DOMAIN_API + PATH;
        setMethod(Request.Method.POST);

        HashMap<String, String> headers = new HashMap<>();
        headers.put("authorization", "Bearer" + " " + CourierService.userToken);
        setHeader(headers);
    }
}
