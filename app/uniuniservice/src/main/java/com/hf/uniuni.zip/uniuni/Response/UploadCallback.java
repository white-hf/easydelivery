package com.hf.uniuni.Response;

import androidx.annotation.NonNull;

import com.hf.courierservice.IResponseCallBack;
import com.hf.courierservice.apihelper.exception.ForbiddenException;
import com.hf.courierservice.apihelper.exception.TooMuchRequestException;
import com.hf.courierservice.apihelper.exception.UnAuthorizedException;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class UploadCallback implements Callback {
    public static final int TOO_MUCH_REQUEST = 429;

    private IResponseCallBack<Void> callback;

    public UploadCallback(IResponseCallBack<Void> callback) {
        this.callback = callback;
    }

    @Override
    public void onFailure(Call call, @NonNull IOException e) {
        callback.onFail(e);
    }

    @Override
    public void onResponse(Call call, @NonNull Response response) throws IOException {
        String bodyString = response.body() != null ? response.body().string() : "";
        if (!response.isSuccessful()) {
            if (response.code() == HttpURLConnection.HTTP_UNAUTHORIZED) {
                // need to login again
                callback.onFail(new UnAuthorizedException());
            } else if (response.code() == HttpURLConnection.HTTP_FORBIDDEN) {
                callback.onFail(new ForbiddenException());
            } else if (response.code() == TOO_MUCH_REQUEST) {
                // too many requests, we need to wait a while.
                callback.onFail(new TooMuchRequestException());
            } else {
                callback.onFail(
                        new Exception("Upload response is unsuccessful:" + response.code() + ", body=" + bodyString));
            }
        } else {
            // Handle successful HTTP response
            if (bodyString != null && !bodyString.isEmpty()) {
                JSONObject jsonResponse = null;
                try {
                    jsonResponse = new JSONObject(bodyString);
                    String bizCode = jsonResponse.getString("biz_code");
                    if (bizCode.equals("DELIVERY.RETRY.SUCCESS") || bizCode.endsWith("SUCCESS")) {
                        callback.onComplete(null);
                    } else {
                        // this situation is unusual, it should not be checked.
                        callback.onFail(new Exception(
                                "Upload response is unsuccessful:" + response.code() + ", biz_code=" + bizCode));
                    }
                } catch (JSONException e) {
                    // this situation is unusual, it should not be checked.
                    callback.onFail(new Exception(
                            "Upload response is unsuccessful because of json exception:" + e.getMessage()));
                }

            } else {
                // this situation is unusual, it should not be checked.
                callback.onFail(new Exception("Upload unsuccessfully due to empty body:"));
            }
        }
    }
}
