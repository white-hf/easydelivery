package com.hf.uniuni.Request;

import com.android.volley.Request;
import com.hf.courierservice.apihelper.ApiRequestBase;
import com.hf.uniuni.Response.ParcelScanRsp;
import com.hf.uniuni.CourierService;

public class ParcelScanTaskApiRequest
        extends ApiRequestBase<ParcelScanReq, ParcelScanRsp> {

    private static final String URL_SCAN =
            CourierService.DOMAIN_API + "delivery/ext/scan";

    public ParcelScanTaskApiRequest(ParcelScanReq req) {
        super(req, ParcelScanRsp.class);
        mUrl = URL_SCAN;
        setMethod(Request.Method.POST);
    }
}
