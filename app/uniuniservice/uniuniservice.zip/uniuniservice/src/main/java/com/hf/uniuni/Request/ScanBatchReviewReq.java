package com.hf.uniuni.Request;

/**
 * 提交扫描批次审核请求参数
 */
public class ScanBatchReviewReq {
    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
