package com.hf.uniuni;

import android.content.Context;

import com.hf.courierservice.ICourierService;
import com.hf.courierservice.IResponseCallBack;
import com.hf.courierservice.Result;
import com.hf.courierservice.apihelper.MultipartUploader;
import com.hf.courierservice.apihelper.exception.UnAuthorizedException;
import com.hf.courierservice.bean.DeliveredUploadParams;
import com.hf.courierservice.bean.DeliveringListData;
import com.hf.courierservice.apihelper.ApiRequestBase;
import com.hf.courierservice.bean.ParcelScanData;
import com.hf.courierservice.bean.ScanBatchCreateData;
import com.hf.courierservice.bean.ScanBatchGenerateReportData;
import com.hf.courierservice.bean.ScanBatchReportData;
import com.hf.courierservice.bean.ScanBatchReviewData;
import com.hf.courierservice.bean.ToBePickedUpBriefData;
import com.hf.uniuni.Request.AppLoginReq;
import com.hf.uniuni.Request.CommonReq;
import com.hf.uniuni.Request.GetDeliveryTaskApiRequest;
import com.hf.uniuni.Request.ParcelScanReq;
import com.hf.uniuni.Request.ParcelScanTaskApiRequest;
import com.hf.uniuni.Request.ScanBatchCreateReq;
import com.hf.uniuni.Request.ScanBatchCreateTaskApiRequest;
import com.hf.uniuni.Request.ScanBatchGenerateReportReq;
import com.hf.uniuni.Request.ScanBatchGenerateReportTaskApiRequest;
import com.hf.uniuni.Request.ScanBatchReportReq;
import com.hf.uniuni.Request.ScanBatchReportTaskApiRequest;
import com.hf.uniuni.Request.ScanBatchReviewReq;
import com.hf.uniuni.Request.ScanBatchReviewTaskApiRequest;
import com.hf.uniuni.Request.ToBePickedUpBriefTaskApiRequest;
import com.hf.uniuni.Request.UserLoginTaskApiRequest;
import com.hf.uniuni.Response.UploadCallback;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Callback;

public class CourierService implements ICourierService {
    public static final String DOMAIN_API = "https://delivery-service-api.uniuni.ca/";
    // public static final String DOMAIN_API = "http://192.168.2.122:9000/";
    // public static final String DOMAIN_API = "http://172.30.242.140:9000/";
    public static String userToken;

    @Override
    public void init(Context context) {
        ApiRequestBase.initRequestQueue(context);
    }

    @Override
    public void login(@NotNull String username, @NotNull String password, IResponseCallBack<String> callback) {
        AppLoginReq req = new AppLoginReq();
        req.setPassword(password);
        req.setCredential_id(username);

        UserLoginTaskApiRequest api = new UserLoginTaskApiRequest(req);
        api.doApi(callback);
    }

    @Override
    public void getPackageList(String userId, boolean bDelivered,
            IResponseCallBack<List<DeliveringListData>> callback) {
        CommonReq req = new CommonReq();
        GetDeliveryTaskApiRequest api = new GetDeliveryTaskApiRequest(req, userId, bDelivered);
        api.doApi(callback);
    }

    @Override
    public boolean uploadDeliveredPackages(DeliveredUploadParams uploadInfo, IResponseCallBack<Void> callback) {
        String DELIVERED_API = DOMAIN_API + "delivery";

        DeliveredUploadParams params = new DeliveredUploadParams();
        params.setUrl(DELIVERED_API);

        if (userToken == null) {
            callback.onFail(new UnAuthorizedException());
            return false;
        }

        params.setAuthorization("Bearer" + " " + userToken);

        Map<String, String> formFields = new LinkedHashMap<>();
        formFields.put("order_id", uploadInfo.getOrderId() == null ? "" : String.valueOf(uploadInfo.getOrderId()));
        formFields.put("longitude",
                uploadInfo.getLongitude() == null ? "0.0" : String.valueOf(uploadInfo.getLongitude()));
        formFields.put("latitude", uploadInfo.getLatitude() == null ? "0.0" : String.valueOf(uploadInfo.getLatitude()));
        params.setFormFields(formFields);
        Map<String, String> trailing = new LinkedHashMap<>();
        int deliveryResult = uploadInfo.getDeliveryResult() == null ? 0 : uploadInfo.getDeliveryResult();
        trailing.put("delivery_result", String.valueOf(deliveryResult));
        if (deliveryResult == 1 && uploadInfo.getFailedReason() != null) {
            trailing.put("failed_reason", String.valueOf(uploadInfo.getFailedReason()));
        }
        trailing.put("recipient_name", uploadInfo.getRecipientName() == null ? "" : uploadInfo.getRecipientName());
        params.setTrailingFields(trailing);

        params.setImageFiles(uploadInfo.getImageFiles());
        Callback cb = new UploadCallback(callback);
        return MultipartUploader.upload(params, cb);
    }

    @Override
    public void retryDelivery(DeliveredUploadParams uploadInfo, IResponseCallBack<Void> callback) {
        String RETRY_API = DOMAIN_API + "delivery/retry";

        DeliveredUploadParams params = new DeliveredUploadParams();
        params.setUrl(RETRY_API);
        params.setImageFieldName("pod_img[]");

        if (userToken == null) {
            callback.onFail(new UnAuthorizedException());
            return;
        }

        params.setAuthorization("Bearer" + " " + userToken);

        Map<String, String> formFields = new LinkedHashMap<>();
        formFields.put("order_id", uploadInfo.getOrderId() == null ? "" : String.valueOf(uploadInfo.getOrderId()));
        formFields.put("longitude",
                uploadInfo.getLongitude() == null ? "0.0" : String.valueOf(uploadInfo.getLongitude()));
        formFields.put("latitude", uploadInfo.getLatitude() == null ? "0.0" : String.valueOf(uploadInfo.getLatitude()));
        params.setFormFields(formFields);

        Map<String, String> trailing = new LinkedHashMap<>();
        trailing.put("driver_id", uploadInfo.getDriverId() == null ? "" : uploadInfo.getDriverId());
        params.setTrailingFields(trailing);

        params.setImageFiles(uploadInfo.getImageFiles());
        Callback cb = new UploadCallback(callback);
        MultipartUploader.upload(params, cb);
    }

    /**
     * Set a package to scanned status. It is the most popular drivers' operation.
     *
     * @param trackingNo It is not order id, and it is like 'BAUNI000300014438615'.
     * @param batchId    It is a scan batch id.
     * @param callback
     */
    @Override
    public void scan(String trackingNo, Long batchId, IResponseCallBack<ParcelScanData> callback) {
        ParcelScanReq req = new ParcelScanReq();
        req.setTracking_no(trackingNo);
        req.setScan_batch_id(batchId);

        new ParcelScanTaskApiRequest(req).doApi(callback);
    }

    @Override
    public void fetchDriverReport(int warehouse, int driverId, String date,
            IResponseCallBack<List<ScanBatchReportData>> callback) {
        ScanBatchReportReq req = new ScanBatchReportReq();
        req.setWarehouse(warehouse);
        req.setDriver_id(driverId);
        req.setStart_date(date);

        new ScanBatchReportTaskApiRequest(req).doApi(callback);
    }

    @Override
    public void fetchToBePickedUpBrief(int driverId, IResponseCallBack<ToBePickedUpBriefData> callback) {
        CommonReq req = new CommonReq();
        new ToBePickedUpBriefTaskApiRequest(req, driverId).doApi(callback);
    }

    @Override
    public void createScanBatch(int driverId, int operatorRole, int scanAs,
            IResponseCallBack<ScanBatchCreateData> callback) {
        ScanBatchCreateReq req = new ScanBatchCreateReq();
        req.setDriver_id(driverId);
        req.setOperator_role(operatorRole);
        req.setScan_as(scanAs);

        new ScanBatchCreateTaskApiRequest(req).doApi(callback);
    }

    @Override
    public void generateScanBatchReport(long scanBatchId, IResponseCallBack<ScanBatchGenerateReportData> callback) {
        ScanBatchGenerateReportReq req = new ScanBatchGenerateReportReq();
        req.setScan_batch_id(scanBatchId);

        new ScanBatchGenerateReportTaskApiRequest(req).doApi(callback);
    }

    @Override
    public void submitScanBatchReview(long scanBatchId, String status,
            IResponseCallBack<ScanBatchReviewData> callback) {
        ScanBatchReviewReq req = new ScanBatchReviewReq();
        req.setStatus(status);

        new ScanBatchReviewTaskApiRequest(scanBatchId, req).doApi(callback);
    }
}
