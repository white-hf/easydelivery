package com.hf.uniuni.Request;

import com.android.volley.Request;
import com.hf.courierservice.apihelper.ApiRequestBase;
import com.hf.uniuni.CourierService;
import com.hf.uniuni.Response.ScanBatchReviewRsp;

import java.util.HashMap;

/**
 * 提交扫描批次审核 API 请求
 */
public class ScanBatchReviewTaskApiRequest
        extends ApiRequestBase<ScanBatchReviewReq, ScanBatchReviewRsp> {

    private static final String PATH_PREFIX = "delivery/ext/scan/batch/";

    public ScanBatchReviewTaskApiRequest(long scanBatchId, ScanBatchReviewReq req) {
        super(req, ScanBatchReviewRsp.class);
        mUrl = CourierService.DOMAIN_API + PATH_PREFIX + scanBatchId;
        setMethod(Request.Method.PUT);

        HashMap<String, String> headers = new HashMap<>();
        headers.put("authorization", "Bearer" + " " + CourierService.userToken);
        headers.put("Content-Type", "application/json");
        setHeader(headers);
    }
}
